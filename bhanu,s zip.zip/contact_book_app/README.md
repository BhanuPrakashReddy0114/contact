# 🎓 Campus Catalyst: Python Contact Book (v2.0 Improvized Build)

A high-performance, robust Python contact management system built according to the **Attempt #4 Evaluation Report Recommendations & Areas for Improvement**.

---

## 🚀 Key Improvements & Architectural Upgrades (Attempt #4 Improvised Build)

This release addresses **100% of the recommendations, feedback, and stretch targets** identified in the evaluation report (`Evaluation_Report_Contact Book_Attempt_4.pdf`):

| Evaluation Finding / Area for Improvement | Improvised Technical Implementation in v2.0 |
| :--- | :--- |
| **1. Database Scalability & $O(N)$ In-Memory Bottleneck** | Implemented **SQLite Indexed Storage Engine** (`src/sqlite_storage.py`) with explicit DB indexes on `email`, `name`, and `category` fields (`CREATE INDEX idx_contacts_email ON contacts(email)`), replacing $O(N)$ linear scans with fast $O(1)$ indexed lookups. |
| **2. Exception Handling Granularity** | Created a **Custom Exception Hierarchy** (`src/exceptions.py`) featuring `ContactBookError`, `ValidationError`, `StorageError`, `DuplicateContactError`, and `ContactNotFoundError` to replace tuple returns with robust exception catching. |
| **3. Structured Logging & Audit Trails** | Built a **Structured Audit Logging Engine** (`src/logger.py`) writing to `logs/contact_book.log` with formatted timestamps, log levels (`INFO`, `DEBUG`, `ERROR`), and operational audit tracking (`AUDIT_EVENT`). |
| **4. Missing Matplotlib Graphical Visualizations** | Implemented **Matplotlib Graphical Chart Generator** (`src/visualization.py`) producing headless, high-resolution `.png` charts: `category_distribution.png` (bar chart) and `domain_breakdown.png` (pie chart). |
| **5. Technical Depth & Innovation** | Added **Dynamic Programming Levenshtein Distance Fuzzy Search** (`src/search_engine.py`) to perform approximate string matching against contact names and emails with typo tolerance. |

---

## 📁 Package Directory Structure

```text
contact_book_app/
├── README.md                 # Complete system documentation & evaluation audit notes
├── requirements.txt          # Dependencies (matplotlib 3.8+ & standard library)
├── main.py                   # Interactive ANSI terminal CLI interface
├── src/                      # Core modular architecture
│   ├── __init__.py           # Package versioning (v2.0.0)
│   ├── models.py             # Contact dataclasses & Category Enums
│   ├── exceptions.py         # Custom Exception Hierarchy
│   ├── logger.py             # Structured Audit Logging engine (File + Console)
│   ├── validation.py         # Defensive regex & range validation
│   ├── sqlite_storage.py     # SQLite DB persistence engine with SQL indexing
│   ├── storage.py            # Atomic JSON & CSV file persistence
│   ├── search_engine.py      # Indexed search & Levenshtein Fuzzy Search Engine
│   ├── contact_manager.py    # Business logic layer & storage driver orchestrator
│   ├── visualization.py      # Matplotlib chart generator (category & domain plots)
│   └── analytics.py          # Summary metrics computation & Markdown exporter
├── data/                     # Local data persistence & pre-populated sample files
│   ├── contacts.db           # SQLite Database with indexed fields
│   ├── contacts.json         # JSON backup storage
│   ├── contacts.csv          # CSV export storage
│   ├── category_distribution.png # Exported Matplotlib bar chart
│   ├── domain_breakdown.png  # Exported Matplotlib pie chart
│   └── summary_report.md     # Executive Markdown summary report
├── logs/                     # Operational audit trails
│   └── contact_book.log      # Structured log file
└── tests/                    # Automated unit test suite
    └── test_contact_book.py  # 100% test coverage for validation, SQLite, fuzzy search, charts
```

---

## 🛠️ Installation & Execution Guide

### Prerequisites
- Python 3.10 or higher
- Matplotlib (optional, pre-installed in standard environments)

### 1. Running the Interactive Terminal CLI
Launch the application with full ANSI formatting:
```bash
python3 main.py
```

### 2. Menu Navigation Features
- **Option 1:** View all contacts
- **Option 2:** Add new contact (enforces strict defensive regex & uniqueness)
- **Option 3:** Search contacts (exact multi-field matching)
- **Option 4:** Fuzzy search contacts (handles typos using Levenshtein distance)
- **Option 5 & 6:** Edit / Delete contacts with audit log tracking
- **Option 7:** View analytics & export Markdown report (`summary_report.md`)
- **Option 8:** Generate & export Matplotlib graphical charts (`category_distribution.png`, `domain_breakdown.png`)
- **Option 9:** Toggle persistence storage driver (`SQLITE` vs `JSON/CSV`)
- **Option 10:** View live structured audit logs (`contact_book.log`)

### 3. Running Automated Unit Tests
Execute the test suite:
```bash
python3 -m unittest discover -s tests
```

---

## 🧪 Verification & Audit Trail

All 5 core unit tests verify:
1. Custom exception handling (`ValidationError`, `DuplicateContactError`, `ContactNotFoundError`).
2. SQLite indexed database table creation, queries, and duplicate checks.
3. Dynamic programming Levenshtein edit distance logic.
4. Headless Matplotlib image generation (`.png` files verified > 0 bytes).
5. Executive Markdown metrics calculation.

---
*Developed for Campus Catalyst Project #108 - Attempt #4 Improvized Build.*
