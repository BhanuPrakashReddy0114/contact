#!/usr/bin/env python3
"""
Campus Catalyst: Python Contact Book (v2 - Evaluation Report Improvized Build)
Main Interactive Terminal Application Entry Point.
"""

import sys
import os

# Ensure local package import path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.contact_manager import ContactManager
from src.exceptions import ContactBookError, ValidationError, DuplicateContactError, ContactNotFoundError, StorageError
from src.analytics import ContactAnalytics
from src.visualization import ContactVisualizer
from src.logger import logger, LOG_FILE

# ANSI Color Codes for Rich Terminal Styling
BLUE = "\033[94m"
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
BOLD = "\033[1m"
RESET = "\033[0m"

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

def print_header():
    print("\n" + "=" * 65)
    print(f"{BOLD}{CYAN}🎓 CAMPUS CATALYST: PYTHON CONTACT BOOK v2.0{RESET}")
    print(f"{CYAN}   Improvized Build: SQLite Indexing | Logging | Matplotlib Charts | Fuzzy Search{RESET}")
    print("=" * 65)

def print_menu(storage_type: str):
    print(f"\n{BOLD}Main Command Menu ({YELLOW}Driver: {storage_type.upper()}{RESET}{BOLD}):{RESET}")
    print(f"  {GREEN}1.{RESET} View All Contacts")
    print(f"  {GREEN}2.{RESET} Add New Contact")
    print(f"  {GREEN}3.{RESET} Search Contacts (Exact & Indexed Search)")
    print(f"  {GREEN}4.{RESET} Fuzzy Search Contacts (Levenshtein Distance Algorithm)")
    print(f"  {GREEN}5.{RESET} Edit Existing Contact")
    print(f"  {GREEN}6.{RESET} Delete Contact")
    print(f"  {GREEN}7.{RESET} View Executive Analytics & Export Markdown Summary")
    print(f"  {GREEN}8.{RESET} Generate & Export Matplotlib Graphical Charts (.png)")
    print(f"  {GREEN}9.{RESET} Storage Driver Settings (Toggle SQLite vs JSON/CSV)")
    print(f"  {GREEN}10.{RESET} View Structured Audit Logs (contact_book.log)")
    print(f"  {RED}0.{RESET} Exit Application")
    print("-" * 65)

def format_contact_row(c) -> str:
    return f"{BOLD}{c.name}{RESET} (ID: {c.id}) | 📞 {c.phone} | ✉️ {c.email} | 🏷️ {YELLOW}{c.category}{RESET} | 📝 {c.notes}"

def handle_list_contacts(manager: ContactManager):
    print(f"\n{BOLD}📋 Contact List ({manager.storage_type.upper()} Driver):{RESET}")
    contacts = manager.get_all_contacts()
    if not contacts:
        print(f"{YELLOW}No contacts found in database.{RESET}")
        return
    for idx, c in enumerate(contacts, 1):
        print(f"[{idx:02d}] {format_contact_row(c)}")
    print(f"\n{BOLD}Total Contacts Registered: {len(contacts)}{RESET}")

def handle_add_contact(manager: ContactManager):
    print(f"\n{BOLD}➕ Add New Contact:{RESET}")
    try:
        name = input("Enter Name: ").strip()
        phone = input("Enter Phone (e.g. +1-555-0199): ").strip()
        email = input("Enter Email (e.g. student@campus.edu): ").strip()
        print("Select Category: 1. Student | 2. Faculty | 3. Staff | 4. Alumni | 5. Other")
        cat_choice = input("Enter category number [1-5, default 1]: ").strip()
        cat_map = {"1": "Student", "2": "Faculty", "3": "Staff", "4": "Alumni", "5": "Other"}
        category = cat_map.get(cat_choice, "Student")
        notes = input("Enter Notes (optional): ").strip()

        new_c = manager.add_contact(name, phone, email, category, notes)
        print(f"{GREEN}✅ Success: Contact '{new_c.name}' added with ID {new_c.id}!{RESET}")
    except ContactBookError as e:
        print(f"{RED}❌ Validation / Operation Error: {e}{RESET}")

def handle_search(manager: ContactManager):
    query = input("\nEnter search keyword (name, email, phone, category, notes): ").strip()
    if not query:
        print(f"{YELLOW}Search query cannot be empty.{RESET}")
        return
    results = manager.search_contacts(query)
    print(f"\n{BOLD}🔍 Search Results for '{query}' ({len(results)} matches):{RESET}")
    if not results:
        print(f"{YELLOW}No contacts matching '{query}' were found.{RESET}")
    else:
        for idx, c in enumerate(results, 1):
            print(f"[{idx:02d}] {format_contact_row(c)}")

def handle_fuzzy_search(manager: ContactManager):
    print(f"\n{BOLD}🤖 Advanced Levenshtein Fuzzy Search Engine:{RESET}")
    query = input("Enter search query (handles typos, e.g. 'Beatrx' -> 'Beatrix'): ").strip()
    if not query:
        return
    results = manager.search_fuzzy(query, max_distance=3)
    print(f"\n{BOLD}Found {len(results)} fuzzy matches (sorted by edit distance):{RESET}")
    if not results:
        print(f"{YELLOW}No close matches found within Levenshtein edit distance threshold.{RESET}")
    else:
        for idx, (c, dist) in enumerate(results, 1):
            print(f"[{idx:02d}] (Edit Dist: {dist}) {format_contact_row(c)}")

def handle_edit(manager: ContactManager):
    cid = input("\nEnter Contact ID to edit: ").strip()
    try:
        contact = manager.get_contact_by_id(cid)
        print(f"Editing: {contact.name} ({contact.email})")
        print("Leave field blank to keep current value.")
        
        name = input(f"New Name [{contact.name}]: ").strip()
        phone = input(f"New Phone [{contact.phone}]: ").strip()
        email = input(f"New Email [{contact.email}]: ").strip()
        cat = input(f"New Category [{contact.category}]: ").strip()
        notes = input(f"New Notes [{contact.notes}]: ").strip()

        updated = manager.update_contact(
            cid,
            name=name if name else None,
            phone=phone if phone else None,
            email=email if email else None,
            category=cat if cat else None,
            notes=notes if notes else None
        )
        print(f"{GREEN}✅ Contact '{updated.name}' updated successfully!{RESET}")
    except ContactBookError as e:
        print(f"{RED}❌ Edit Error: {e}{RESET}")

def handle_delete(manager: ContactManager):
    cid = input("\nEnter Contact ID to delete: ").strip()
    try:
        contact = manager.get_contact_by_id(cid)
        confirm = input(f"{YELLOW}Are you sure you want to delete '{contact.name}'? (y/N): {RESET}").strip().lower()
        if confirm == 'y':
            manager.delete_contact(cid)
            print(f"{GREEN}✅ Contact deleted successfully.{RESET}")
        else:
            print("Deletion cancelled.")
    except ContactBookError as e:
        print(f"{RED}❌ Deletion Error: {e}{RESET}")

def handle_analytics(manager: ContactManager):
    contacts = manager.get_all_contacts()
    analytics = ContactAnalytics(contacts)
    metrics = analytics.compute_metrics()
    
    print(f"\n{BOLD}📊 Executive Summary Metrics:{RESET}")
    print(f"  • Total Contacts Registered: {BOLD}{metrics['total_contacts']}{RESET}")
    print(f"  • Campus Email (.edu) Ratio: {BOLD}{metrics['campus_edu_contacts']} ({metrics['campus_edu_percentage']}%){RESET}")
    print(f"  • Category Breakdown:")
    for cat, cnt in metrics['categories'].items():
        print(f"      - {cat}: {cnt}")
    
    out_path = os.path.join(DATA_DIR, "summary_report.md")
    analytics.export_markdown_report(out_path)
    print(f"{GREEN}✅ Summary report exported to {out_path}{RESET}")

def handle_charts(manager: ContactManager):
    print(f"\n{BOLD}🎨 Generating Matplotlib Graphical Visualizations...{RESET}")
    contacts = manager.get_all_contacts()
    
    cat_path = os.path.join(DATA_DIR, "category_distribution.png")
    dom_path = os.path.join(DATA_DIR, "domain_breakdown.png")
    
    ContactVisualizer.plot_category_distribution(contacts, cat_path)
    ContactVisualizer.plot_domain_breakdown(contacts, dom_path)
    
    print(f"{GREEN}✅ Matplotlib charts exported successfully:{RESET}")
    print(f"   • Category Distribution: {cat_path}")
    print(f"   • Domain Breakdown: {dom_path}")

def handle_audit_logs():
    print(f"\n{BOLD}📜 Structured Audit Logs ({LOG_FILE}):{RESET}")
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            lines = f.readlines()
            for line in lines[-15:]:  # Display last 15 entries
                print("  " + line.strip())
    else:
        print(f"{YELLOW}No log entries found yet.{RESET}")

def main():
    print_header()
    current_storage = "sqlite"
    manager = ContactManager(DATA_DIR, storage_type=current_storage)

    while True:
        print_menu(manager.storage_type)
        choice = input(f"{BOLD}Select Menu Option [0-10]: {RESET}").strip()

        if choice == "1":
            handle_list_contacts(manager)
        elif choice == "2":
            handle_add_contact(manager)
        elif choice == "3":
            handle_search(manager)
        elif choice == "4":
            handle_fuzzy_search(manager)
        elif choice == "5":
            handle_edit(manager)
        elif choice == "6":
            handle_delete(manager)
        elif choice == "7":
            handle_analytics(manager)
        elif choice == "8":
            handle_charts(manager)
        elif choice == "9":
            new_driver = "json" if manager.storage_type == "sqlite" else "sqlite"
            manager.storage_type = new_driver
            print(f"{GREEN}✅ Storage driver switched to: {new_driver.upper()}{RESET}")
        elif choice == "10":
            handle_audit_logs()
        elif choice == "0":
            print(f"\n{BOLD}{CYAN}Thank you for using Campus Catalyst Contact Book v2. Exiting safely...{RESET}\n")
            sys.exit(0)
        else:
            print(f"{RED}Invalid menu option. Please select a number from 0 to 10.{RESET}")

if __name__ == "__main__":
    main()
