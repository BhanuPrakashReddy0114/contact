"""
Core Business Logic Engine (ContactManager) for Campus Catalyst Contact Book.
Integrates custom exception hierarchy, structured audit logging, and SQLite/JSON/CSV drivers.
"""

from typing import List, Optional, Tuple
from datetime import datetime
import os

from src.models import Contact, Category
from src.validation import Validator
from src.exceptions import ContactNotFoundError, DuplicateContactError, ValidationError, StorageError
from src.storage import StorageManager
from src.sqlite_storage import SQLiteStorage
from src.search_engine import AdvancedSearchEngine
from src.logger import logger, log_audit_event

class ContactManager:
    def __init__(self, data_dir: str, storage_type: str = "sqlite"):
        self.data_dir = data_dir
        self.storage_type = storage_type.lower()
        self.json_csv_storage = StorageManager(data_dir)
        
        db_path = os.path.join(data_dir, "contacts.db")
        self.sqlite_storage = SQLiteStorage(db_path)
        
        self._sync_initial_state()

    def _sync_initial_state(self):
        """Initializes SQLite database from JSON/CSV if empty."""
        try:
            sqlite_contacts = self.sqlite_storage.load_all()
            if not sqlite_contacts:
                json_contacts = self.json_csv_storage.load_json("contacts.json")
                if json_contacts:
                    for c in json_contacts:
                        try:
                            self.sqlite_storage.insert(c)
                        except DuplicateContactError:
                            pass
                    logger.info(f"Seeded {len(json_contacts)} contacts from JSON into SQLite database.")
        except Exception as e:
            logger.warning(f"Initial state sync notice: {e}")

    def get_all_contacts(self) -> List[Contact]:
        if self.storage_type == "sqlite":
            return self.sqlite_storage.load_all()
        else:
            return self.json_csv_storage.load_json("contacts.json")

    def get_contact_by_id(self, contact_id: str) -> Contact:
        contacts = self.get_all_contacts()
        for c in contacts:
            if c.id == contact_id:
                return c
        raise ContactNotFoundError(f"Contact with ID '{contact_id}' was not found.")

    def add_contact(self, name: str, phone: str, email: str, category: str = "Student", notes: str = "") -> Contact:
        """Validates payload, checks uniqueness, creates contact, and logs audit event."""
        payload = Validator.validate_contact_payload(name, phone, email, category, notes)
        
        # Check uniqueness by email
        existing_contacts = self.get_all_contacts()
        for c in existing_contacts:
            if c.email.lower() == payload["email"].lower():
                raise DuplicateContactError(f"A contact with email '{payload['email']}' already exists.")

        new_contact = Contact(
            name=payload["name"],
            phone=payload["phone"],
            email=payload["email"],
            category=payload["category"],
            notes=payload["notes"]
        )

        # Persist based on active driver
        if self.storage_type == "sqlite":
            self.sqlite_storage.insert(new_contact)
            # Sync to JSON and CSV for dual persistence
            all_c = self.sqlite_storage.load_all()
            self.json_csv_storage.save_json(all_c)
            self.json_csv_storage.save_csv(all_c)
        else:
            all_c = self.get_all_contacts()
            all_c.append(new_contact)
            self.json_csv_storage.save_json(all_c)
            self.json_csv_storage.save_csv(all_c)

        log_audit_event("CREATE", new_contact.id, f"Added contact '{new_contact.name}' ({new_contact.email})")
        return new_contact

    def update_contact(self, contact_id: str, name: str = None, phone: str = None, email: str = None, category: str = None, notes: str = None) -> Contact:
        existing = self.get_contact_by_id(contact_id)
        
        new_name = Validator.validate_name(name) if name is not None else existing.name
        new_phone = Validator.validate_phone(phone) if phone is not None else existing.phone
        new_email = Validator.validate_email(email) if email is not None else existing.email
        new_cat = Validator.validate_category(category) if category is not None else existing.category
        new_notes = notes.strip() if notes is not None else existing.notes

        # Email duplicate check if changed
        if new_email.lower() != existing.email.lower():
            for c in self.get_all_contacts():
                if c.id != contact_id and c.email.lower() == new_email.lower():
                    raise DuplicateContactError(f"Email '{new_email}' is already used by another contact.")

        existing.name = new_name
        existing.phone = new_phone
        existing.email = new_email
        existing.category = new_cat
        existing.notes = new_notes
        existing.updated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if self.storage_type == "sqlite":
            self.sqlite_storage.update(existing)
            all_c = self.sqlite_storage.load_all()
            self.json_csv_storage.save_json(all_c)
            self.json_csv_storage.save_csv(all_c)
        else:
            all_c = [c if c.id != contact_id else existing for c in self.get_all_contacts()]
            self.json_csv_storage.save_json(all_c)
            self.json_csv_storage.save_csv(all_c)

        log_audit_event("UPDATE", existing.id, f"Updated contact '{existing.name}'")
        return existing

    def delete_contact(self, contact_id: str) -> bool:
        contact = self.get_contact_by_id(contact_id)
        
        if self.storage_type == "sqlite":
            deleted = self.sqlite_storage.delete(contact_id)
            all_c = self.sqlite_storage.load_all()
            self.json_csv_storage.save_json(all_c)
            self.json_csv_storage.save_csv(all_c)
        else:
            all_c = [c for c in self.get_all_contacts() if c.id != contact_id]
            self.json_csv_storage.save_json(all_c)
            self.json_csv_storage.save_csv(all_c)
            deleted = True

        log_audit_event("DELETE", contact_id, f"Deleted contact '{contact.name}' ({contact.email})")
        return deleted

    def search_contacts(self, query: str) -> List[Contact]:
        if self.storage_type == "sqlite":
            return self.sqlite_storage.search_indexed(query)
        else:
            all_c = self.get_all_contacts()
            return AdvancedSearchEngine.exact_keyword_search(all_c, query)

    def search_fuzzy(self, query: str, max_distance: int = 2) -> List[Tuple[Contact, int]]:
        all_c = self.get_all_contacts()
        return AdvancedSearchEngine.fuzzy_search(all_c, query, max_distance)
