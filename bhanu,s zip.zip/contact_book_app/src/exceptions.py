"""
Custom Exception Hierarchy for Campus Catalyst Contact Book Application.
Provides granular error handling across validation, storage, and logic modules.
"""

class ContactBookError(Exception):
    """Base exception class for all Contact Book application errors."""
    def __init__(self, message: str, details: str = None):
        super().__init__(message)
        self.message = message
        self.details = details

    def __str__(self):
        if self.details:
            return f"{self.message} (Details: {self.details})"
        return self.message


class ValidationError(ContactBookError):
    """Raised when contact input fails field formatting or domain validation."""
    pass


class StorageError(ContactBookError):
    """Raised when reading, writing, or serializing data fails."""
    pass


class ContactNotFoundError(ContactBookError):
    """Raised when a requested contact cannot be found by ID, email, or name."""
    pass


class DuplicateContactError(ContactBookError):
    """Raised when attempting to add a contact with a pre-existing unique field (e.g. email)."""
    pass
