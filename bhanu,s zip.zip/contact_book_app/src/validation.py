"""
Defensive Input Validation Engine for Contact Book.
Raises ValidationError on non-conforming inputs.
"""

import re
from src.exceptions import ValidationError
from src.models import Category

# Flexible phone regex allowing international & local formats (+1-555-0199, 555-0199, (555) 012-3456)
PHONE_REGEX = re.compile(r"^\+?[0-9\-\.\s\(\)]{7,20}$")
EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")

class Validator:
    @staticmethod
    def validate_name(name: str) -> str:
        cleaned = name.strip()
        if not cleaned:
            raise ValidationError("Contact name cannot be empty.")
        if len(cleaned) < 2:
            raise ValidationError("Contact name must be at least 2 characters long.")
        if len(cleaned) > 100:
            raise ValidationError("Contact name exceeds maximum length of 100 characters.")
        return cleaned

    @staticmethod
    def validate_phone(phone: str) -> str:
        cleaned = phone.strip()
        digits_only = re.sub(r"[\s\-\(\)\+]", "", cleaned)
        if not digits_only:
            raise ValidationError("Phone number cannot be empty.")
        if len(digits_only) < 7 or len(digits_only) > 15:
            raise ValidationError("Phone number must contain between 7 and 15 digits.")
        if not PHONE_REGEX.match(cleaned):
            raise ValidationError("Invalid phone number format. Examples: 555-0199, +1-555-0199, (555) 012-3456.")
        return cleaned

    @staticmethod
    def validate_email(email: str) -> str:
        cleaned = email.strip().lower()
        if not cleaned:
            raise ValidationError("Email address cannot be empty.")
        if not EMAIL_REGEX.match(cleaned):
            raise ValidationError("Invalid email address format (expected user@domain.com).")
        return cleaned

    @staticmethod
    def validate_category(category_str: str) -> str:
        cleaned = category_str.strip()
        cat_enum = Category.from_string(cleaned)
        return cat_enum.value

    @classmethod
    def validate_contact_payload(cls, name: str, phone: str, email: str, category: str = "Student", notes: str = "") -> dict:
        validated_name = cls.validate_name(name)
        validated_phone = cls.validate_phone(phone)
        validated_email = cls.validate_email(email)
        validated_cat = cls.validate_category(category)
        return {
            "name": validated_name,
            "phone": validated_phone,
            "email": validated_email,
            "category": validated_cat,
            "notes": notes.strip() if notes else ""
        }
