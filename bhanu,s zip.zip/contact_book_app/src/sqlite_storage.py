"""
SQLite Persistence Engine with Field Indexing for Scalable O(1)/Indexed Lookups.
Addresses Attempt #4 Evaluation Report Recommendation #2.
"""

import sqlite3
import os
from typing import List, Optional
from src.models import Contact
from src.exceptions import StorageError, DuplicateContactError
from src.logger import logger

class SQLiteStorage:
    def __init__(self, db_path: str):
        self.db_path = db_path
        os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            return conn
        except sqlite3.Error as e:
            logger.error(f"Failed to connect to SQLite database at {self.db_path}: {e}")
            raise StorageError(f"Database connection error: {e}")

    def _init_db(self):
        """Initializes schema and creates DB INDEXES for fast lookup scalability."""
        create_table_sql = """
        CREATE TABLE IF NOT EXISTS contacts (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            category TEXT NOT NULL,
            notes TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        """
        # Create explicit indexes on search columns to solve O(N) memory scanning
        idx_email = "CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email);"
        idx_name = "CREATE INDEX IF NOT EXISTS idx_contacts_name ON contacts(name);"
        idx_category = "CREATE INDEX IF NOT EXISTS idx_contacts_category ON contacts(category);"

        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(create_table_sql)
                cursor.execute(idx_email)
                cursor.execute(idx_name)
                cursor.execute(idx_category)
                conn.commit()
                logger.info(f"SQLite database initialized with indexes at {self.db_path}")
        except sqlite3.Error as e:
            raise StorageError(f"Failed to initialize database schema: {e}")

    def insert(self, contact: Contact) -> Contact:
        sql = """
        INSERT INTO contacts (id, name, phone, email, category, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(sql, contact.to_sqlite_tuple())
                conn.commit()
                logger.debug(f"Inserted contact {contact.id} into SQLite DB.")
                return contact
        except sqlite3.IntegrityError:
            raise DuplicateContactError(f"Contact with email '{contact.email}' already exists in SQLite database.")
        except sqlite3.Error as e:
            raise StorageError(f"SQLite insert failed: {e}")

    def update(self, contact: Contact) -> Contact:
        sql = """
        UPDATE contacts
        SET name = ?, phone = ?, email = ?, category = ?, notes = ?, updated_at = ?
        WHERE id = ?;
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(sql, (
                    contact.name, contact.phone, contact.email,
                    contact.category, contact.notes, contact.updated_at,
                    contact.id
                ))
                conn.commit()
                return contact
        except sqlite3.Error as e:
            raise StorageError(f"SQLite update failed: {e}")

    def delete(self, contact_id: str) -> bool:
        sql = "DELETE FROM contacts WHERE id = ?;"
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(sql, (contact_id,))
                conn.commit()
                return cursor.rowcount > 0
        except sqlite3.Error as e:
            raise StorageError(f"SQLite delete failed: {e}")

    def get_by_id(self, contact_id: str) -> Optional[Contact]:
        sql = "SELECT * FROM contacts WHERE id = ?;"
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(sql, (contact_id,))
                row = cursor.fetchone()
                if row:
                    return Contact.from_dict(dict(row))
                return None
        except sqlite3.Error as e:
            raise StorageError(f"SQLite lookup failed: {e}")

    def get_by_email(self, email: str) -> Optional[Contact]:
        """Indexed O(1) email lookup."""
        sql = "SELECT * FROM contacts WHERE email = ?;"
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(sql, (email.strip().lower(),))
                row = cursor.fetchone()
                if row:
                    return Contact.from_dict(dict(row))
                return None
        except sqlite3.Error as e:
            raise StorageError(f"SQLite email lookup failed: {e}")

    def load_all(self) -> List[Contact]:
        sql = "SELECT * FROM contacts ORDER BY name ASC;"
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(sql)
                rows = cursor.fetchall()
                return [Contact.from_dict(dict(r)) for r in rows]
        except sqlite3.Error as e:
            raise StorageError(f"SQLite load all failed: {e}")

    def search_indexed(self, query: str) -> List[Contact]:
        """Indexed SQL pattern matching."""
        pattern = f"%{query.strip().lower()}%"
        sql = """
        SELECT * FROM contacts
        WHERE lower(name) LIKE ? OR lower(email) LIKE ? OR lower(phone) LIKE ? OR lower(category) LIKE ? OR lower(notes) LIKE ?
        ORDER BY name ASC;
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(sql, (pattern, pattern, pattern, pattern, pattern))
                rows = cursor.fetchall()
                return [Contact.from_dict(dict(r)) for r in rows]
        except sqlite3.Error as e:
            raise StorageError(f"SQLite search failed: {e}")
