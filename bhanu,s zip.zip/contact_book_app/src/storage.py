"""
Atomic JSON and CSV Storage Persistence Engine.
Ensures atomic temp-file writes to prevent file corruption on disk.
"""

import json
import csv
import os
import shutil
from typing import List
from src.models import Contact
from src.exceptions import StorageError
from src.logger import logger

class StorageManager:
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)

    def save_json(self, contacts: List[Contact], filename: str = "contacts.json") -> str:
        file_path = os.path.join(self.data_dir, filename)
        temp_path = file_path + ".tmp"
        try:
            data = [c.to_dict() for c in contacts]
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            shutil.move(temp_path, file_path)
            logger.debug(f"Atomically saved {len(contacts)} contacts to JSON: {file_path}")
            return file_path
        except Exception as e:
            if os.path.exists(temp_path):
                os.remove(temp_path)
            logger.error(f"Failed saving JSON data: {e}")
            raise StorageError(f"JSON persistence error: {e}")

    def load_json(self, filename: str = "contacts.json") -> List[Contact]:
        file_path = os.path.join(self.data_dir, filename)
        if not os.path.exists(file_path):
            logger.info(f"JSON file {file_path} not found. Returning empty list.")
            return []
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return [Contact.from_dict(item) for item in data]
        except (json.JSONDecodeError, OSError) as e:
            logger.error(f"Corrupted or invalid JSON file at {file_path}: {e}")
            raise StorageError(f"Corrupted or unreadable JSON file: {e}")

    def save_csv(self, contacts: List[Contact], filename: str = "contacts.csv") -> str:
        file_path = os.path.join(self.data_dir, filename)
        temp_path = file_path + ".tmp"
        try:
            fieldnames = ["id", "name", "phone", "email", "category", "notes", "created_at", "updated_at"]
            with open(temp_path, "w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for c in contacts:
                    writer.writerow(c.to_dict())
            shutil.move(temp_path, file_path)
            logger.debug(f"Atomically saved {len(contacts)} contacts to CSV: {file_path}")
            return file_path
        except Exception as e:
            if os.path.exists(temp_path):
                os.remove(temp_path)
            logger.error(f"Failed saving CSV data: {e}")
            raise StorageError(f"CSV persistence error: {e}")

    def load_csv(self, filename: str = "contacts.csv") -> List[Contact]:
        file_path = os.path.join(self.data_dir, filename)
        if not os.path.exists(file_path):
            logger.info(f"CSV file {file_path} not found. Returning empty list.")
            return []
        try:
            contacts = []
            with open(file_path, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    contacts.append(Contact.from_dict(row))
            return contacts
        except Exception as e:
            logger.error(f"Failed loading CSV file at {file_path}: {e}")
            raise StorageError(f"CSV reading error: {e}")
