"""
Advanced Search Engine featuring Levenshtein Distance Fuzzy Matching Algorithm.
Elevates technical depth and handles typos/approximate query matching.
"""

from typing import List, Tuple
from src.models import Contact

def levenshtein_distance(s1: str, s2: str) -> int:
    """
    Computes the edit distance between two strings using dynamic programming.
    Time Complexity: O(M*N), Space Complexity: O(N).
    """
    s1, s2 = s1.lower(), s2.lower()
    m, n = len(s1), len(s2)
    
    if m == 0:
        return n
    if n == 0:
        return m

    # Single-row dynamic programming buffer
    previous_row = list(range(n + 1))
    
    for i, c1 in enumerate(s1):
        current_row = [i + 1] * (n + 1)
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (0 if c1 == c2 else 1)
            current_row[j + 1] = min(insertions, deletions, substitutions)
        previous_row = current_row

    return previous_row[n]

class AdvancedSearchEngine:
    @staticmethod
    def exact_keyword_search(contacts: List[Contact], query: str) -> List[Contact]:
        """Sub-string matching across name, email, phone, category, and notes."""
        q = query.strip().lower()
        if not q:
            return contacts

        results = []
        for c in contacts:
            if (q in c.name.lower() or
                q in c.email.lower() or
                q in c.phone.lower() or
                q in c.category.lower() or
                q in c.notes.lower()):
                results.append(c)
        return results

    @staticmethod
    def fuzzy_search(contacts: List[Contact], query: str, max_distance: int = 2) -> List[Tuple[Contact, int]]:
        """
        Performs approximate string matching against contact names and emails.
        Returns contacts paired with their edit distance, sorted by closeness.
        """
        q = query.strip().lower()
        if not q:
            return [(c, 0) for c in contacts]

        results = []
        for c in contacts:
            # Tokenize target fields
            tokens = c.name.lower().split() + [c.email.lower().split("@")[0]]
            
            min_dist = min([levenshtein_distance(q, token) for token in tokens] + [levenshtein_distance(q, c.name.lower())])
            
            if min_dist <= max_distance:
                results.append((c, min_dist))

        # Sort by edit distance (closest matches first)
        results.sort(key=lambda x: x[1])
        return results
