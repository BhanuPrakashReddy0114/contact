"""
Structured Audit Logging Module for Campus Catalyst Contact Book.
Logs operational events, CRUD activities, errors, and system metrics.
"""

import logging
import os
from datetime import datetime

LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
LOG_FILE = os.path.join(LOG_DIR, "contact_book.log")

def setup_logger(name: str = "ContactBook", level: int = logging.INFO) -> logging.Logger:
    """Configures and returns a structured logger with File and Console handlers."""
    os.makedirs(LOG_DIR, exist_ok=True)
    
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Avoid duplicate handlers if already configured
    if logger.handlers:
        return logger
        
    # File Handler - Detailed Audit Log
    file_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
    file_formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    file_handler.setFormatter(file_formatter)
    file_handler.setLevel(logging.DEBUG)
    logger.addHandler(file_handler)
    
    return logger

logger = setup_logger()

def log_audit_event(action: str, target_id: str, details: str = ""):
    """Logs a structured audit event for user actions."""
    timestamp = datetime.now().isoformat()
    logger.info(f"AUDIT_EVENT | Action: {action} | ID: {target_id} | Details: {details}")
