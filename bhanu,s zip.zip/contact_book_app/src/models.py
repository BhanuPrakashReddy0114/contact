"""
Data Models and Dataclasses for Campus Catalyst Contact Book.
"""

from dataclasses import dataclass, field, asdict
from enum import Enum
from datetime import datetime
import uuid
from typing import Dict, Any

class Category(str, Enum):
    STUDENT = "Student"
    FACULTY = "Faculty"
    STAFF = "Staff"
    ALUMNI = "Alumni"
    OTHER = "Other"

    @classmethod
    def from_string(cls, value: str) -> 'Category':
        val_lower = str(value).strip().lower()
        for cat in cls:
            if cat.value.lower() == val_lower:
                return cat
        return cls.OTHER

@dataclass
class Contact:
    name: str
    phone: str
    email: str
    category: str = Category.STUDENT.value
    notes: str = ""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    created_at: str = field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    updated_at: str = field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    def __post_init__(self):
        # Normalize category to standardized string value
        if isinstance(self.category, Category):
            self.category = self.category.value
        else:
            self.category = Category.from_string(self.category).value

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Contact':
        return cls(
            id=data.get("id", str(uuid.uuid4())[:8]),
            name=data.get("name", ""),
            phone=data.get("phone", ""),
            email=data.get("email", ""),
            category=data.get("category", Category.STUDENT.value),
            notes=data.get("notes", ""),
            created_at=data.get("created_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            updated_at=data.get("updated_at", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        )

    def to_sqlite_tuple(self) -> tuple:
        return (
            self.id,
            self.name,
            self.phone,
            self.email,
            self.category,
            self.notes,
            self.created_at,
            self.updated_at
        )
