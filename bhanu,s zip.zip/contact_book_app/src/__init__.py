"""
Campus Catalyst Contact Book Package Header.
"""

__version__ = "2.0.0"
__author__ = "Campus Catalyst Student Team"
