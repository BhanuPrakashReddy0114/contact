"""
Matplotlib Graphical Chart Generation Module for Campus Catalyst Contact Book.
Generates publication-quality charts for category distribution and domain metrics.
Addresses Attempt #4 Evaluation Report Area for Improvement #3.
"""

import os
from typing import List, Dict
from collections import Counter
import matplotlib
matplotlib.use('Agg')  # Headless execution mode
import matplotlib.pyplot as plt
from src.models import Contact
from src.logger import logger

class ContactVisualizer:
    @staticmethod
    def plot_category_distribution(contacts: List[Contact], output_path: str = "category_distribution.png") -> str:
        """Generates a bar chart showing contact count breakdown by category."""
        if not contacts:
            logger.warning("No contacts available to plot category distribution.")
            return ""

        categories = [c.category for c in contacts]
        counts = Counter(categories)

        fig, ax = plt.subplots(figsize=(8, 5))
        bars = ax.bar(counts.keys(), counts.values(), color=['#2b5c8f', '#4682b4', '#6baed6', '#9ecae1', '#c6dbef'])
        
        ax.set_title("Contact Distribution by Campus Role / Category", fontsize=14, fontweight='bold', pad=15)
        ax.set_xlabel("Category", fontsize=11, labelpad=10)
        ax.set_ylabel("Number of Contacts", fontsize=11, labelpad=10)
        ax.grid(axis='y', linestyle='--', alpha=0.7)
        
        # Add value labels on top of bars
        for bar in bars:
            height = bar.get_height()
            ax.annotate(f'{height}',
                        xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, 3),  # 3 points vertical offset
                        textcoords="offset points",
                        ha='center', va='bottom', fontweight='bold')

        plt.tight_layout()
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        plt.savefig(output_path, dpi=200)
        plt.close(fig)
        logger.info(f"Generated category distribution chart at {output_path}")
        return output_path

    @staticmethod
    def plot_domain_breakdown(contacts: List[Contact], output_path: str = "domain_breakdown.png") -> str:
        """Generates a pie chart breakdown of email domains (e.g., .edu vs others)."""
        if not contacts:
            return ""

        domains = []
        for c in contacts:
            if "@" in c.email:
                domain = c.email.split("@")[1].lower()
                domains.append(domain)
            else:
                domains.append("unknown")

        counts = Counter(domains)
        
        # Group minor domains into 'Other' if more than 5 distinct domains
        if len(counts) > 5:
            top_domains = counts.most_common(4)
            other_count = sum(c for d, c in counts.items() if d not in dict(top_domains))
            data_dict = dict(top_domains)
            data_dict["other"] = other_count
        else:
            data_dict = counts

        fig, ax = plt.subplots(figsize=(7, 7))
        ax.pie(
            data_dict.values(),
            labels=data_dict.keys(),
            autopct='%1.1f%%',
            startangle=140,
            colors=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']
        )
        ax.set_title("Email Domain Composition Analysis", fontsize=14, fontweight='bold')

        plt.tight_layout()
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        plt.savefig(output_path, dpi=200)
        plt.close(fig)
        logger.info(f"Generated domain breakdown chart at {output_path}")
        return output_path
