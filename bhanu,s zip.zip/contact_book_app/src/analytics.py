"""
Analytics & Summary Export Module for Campus Catalyst Contact Book.
Generates metrics, category counts, campus domain indicators, and Markdown/CSV exports.
"""

from typing import List, Dict, Any
from collections import Counter
from datetime import datetime
import os
from src.models import Contact
from src.logger import logger

class ContactAnalytics:
    def __init__(self, contacts: List[Contact]):
        self.contacts = contacts

    def compute_metrics(self) -> Dict[str, Any]:
        total_count = len(self.contacts)
        categories = Counter([c.category for c in self.contacts])
        
        edu_count = sum(1 for c in self.contacts if c.email.lower().endswith(".edu"))
        edu_percentage = (edu_count / total_count * 100) if total_count > 0 else 0.0
        
        has_notes_count = sum(1 for c in self.contacts if c.notes.strip())

        return {
            "total_contacts": total_count,
            "categories": dict(categories),
            "campus_edu_contacts": edu_count,
            "campus_edu_percentage": round(edu_percentage, 1),
            "contacts_with_notes": has_notes_count,
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

    def export_markdown_report(self, output_path: str = "summary_report.md") -> str:
        metrics = self.compute_metrics()
        
        md_content = f"""# 📊 Campus Catalyst Contact Book - Executive Summary Report
**Generated At:** {metrics['generated_at']}

---

## 📈 Key Application Metrics
- **Total Registered Contacts:** `{metrics['total_contacts']}`
- **Campus Email (.edu) Integration:** `{metrics['campus_edu_contacts']} ({metrics['campus_edu_percentage']}%)`
- **Contacts with Supplemental Notes:** `{metrics['contacts_with_notes']}`

---

## 🏷️ Category Breakdown
| Category | Contact Count | Percentage |
| :--- | :--- | :--- |
"""
        total = metrics['total_contacts']
        for cat, count in metrics['categories'].items():
            pct = round((count / total * 100), 1) if total > 0 else 0.0
            md_content += f"| **{cat}** | {count} | {pct}% |\n"

        md_content += """
---
## ⚠️ System Health & Audit Threshold Warnings
"""
        if metrics['total_contacts'] == 0:
            md_content += "- ⚠️ **WARNING:** Contact book database is currently empty.\n"
        elif metrics['campus_edu_percentage'] < 50.0:
            md_content += f"- 💡 **NOTICE:** Campus email ratio is {metrics['campus_edu_percentage']}%. Consider auditing external domain entries.\n"
        else:
            md_content += "- ✅ **STATUS:** All operational thresholds within normal campus parameters.\n"

        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(md_content)
        
        logger.info(f"Exported Markdown summary report to {output_path}")
        return output_path
