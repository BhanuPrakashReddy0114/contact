"""
Automated Unit Test Suite for Campus Catalyst Contact Book (v2.0 Improvized Build).
Validates custom exceptions, defensive validation, SQLite indexing, logger, fuzzy search, and charts.
"""

import unittest
import os
import shutil
import tempfile
import sys

# Ensure local imports work cleanly
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.models import Contact, Category
from src.exceptions import ValidationError, DuplicateContactError, ContactNotFoundError, StorageError
from src.validation import Validator
from src.sqlite_storage import SQLiteStorage
from src.storage import StorageManager
from src.contact_manager import ContactManager
from src.search_engine import AdvancedSearchEngine, levenshtein_distance
from src.analytics import ContactAnalytics
from src.visualization import ContactVisualizer

class TestContactBookV2(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.manager = ContactManager(self.test_dir, storage_type="sqlite")

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_custom_exception_validation(self):
        """Test defensive input validation and custom exception raising."""
        with self.assertRaises(ValidationError):
            Validator.validate_name("")
        
        with self.assertRaises(ValidationError):
            Validator.validate_phone("invalid-phone")
            
        with self.assertRaises(ValidationError):
            Validator.validate_email("not-an-email")

        # Valid inputs
        self.assertEqual(Validator.validate_name("Alice Smith"), "Alice Smith")
        self.assertEqual(Validator.validate_email("alice@campus.edu"), "alice@campus.edu")

    def test_sqlite_crud_and_indexing(self):
        """Test SQLite indexed database CRUD operations and duplicate email detection."""
        contact = self.manager.add_contact(
            name="John Doe",
            phone="+1-555-0199",
            email="johndoe@campus.edu",
            category="Student",
            notes="Test Note"
        )
        self.assertIsNotNone(contact.id)
        self.assertEqual(contact.name, "John Doe")

        # Test duplicate email prevention custom exception
        with self.assertRaises(DuplicateContactError):
            self.manager.add_contact(
                name="Duplicate John",
                phone="+1-555-0200",
                email="johndoe@campus.edu",
                category="Student"
            )

        # Lookup by ID
        retrieved = self.manager.get_contact_by_id(contact.id)
        self.assertEqual(retrieved.email, "johndoe@campus.edu")

        # Update contact
        updated = self.manager.update_contact(contact.id, name="Johnathan Doe")
        self.assertEqual(updated.name, "Johnathan Doe")

        # Delete contact
        self.assertTrue(self.manager.delete_contact(contact.id))
        
        with self.assertRaises(ContactNotFoundError):
            self.manager.get_contact_by_id(contact.id)

    def test_levenshtein_fuzzy_search(self):
        """Test dynamic programming Levenshtein distance calculation and fuzzy query matching."""
        self.assertEqual(levenshtein_distance("kitten", "sitting"), 3)
        self.assertEqual(levenshtein_distance("Beatrix", "Beatrx"), 1)

        self.manager.add_contact("Dr. Beatrix Vance", "+1-555-0102", "bvance@campus.edu", "Faculty")
        
        results = self.manager.search_fuzzy("Beatrx", max_distance=2)
        self.assertTrue(len(results) > 0)
        self.assertEqual(results[0][0].name, "Dr. Beatrix Vance")

    def test_matplotlib_visualization(self):
        """Test Matplotlib graphical chart rendering in headless mode."""
        c1 = Contact(name="A", phone="1234567890", email="a@campus.edu", category="Student")
        c2 = Contact(name="B", phone="1234567890", email="b@campus.edu", category="Faculty")
        
        cat_chart_path = os.path.join(self.test_dir, "test_cat.png")
        dom_chart_path = os.path.join(self.test_dir, "test_dom.png")
        
        res1 = ContactVisualizer.plot_category_distribution([c1, c2], cat_chart_path)
        res2 = ContactVisualizer.plot_domain_breakdown([c1, c2], dom_chart_path)
        
        self.assertTrue(os.path.exists(res1))
        self.assertTrue(os.path.exists(res2))
        self.assertTrue(os.path.getsize(res1) > 0)
        self.assertTrue(os.path.getsize(res2) > 0)

    def test_analytics_and_report_export(self):
        """Test metric calculation and Markdown report generation."""
        self.manager.add_contact("Student A", "+1-555-0101", "a@campus.edu", "Student")
        contacts = self.manager.get_all_contacts()
        
        analytics = ContactAnalytics(contacts)
        metrics = analytics.compute_metrics()
        
        self.assertEqual(metrics["total_contacts"], 1)
        self.assertEqual(metrics["campus_edu_percentage"], 100.0)

        report_path = os.path.join(self.test_dir, "summary.md")
        analytics.export_markdown_report(report_path)
        self.assertTrue(os.path.exists(report_path))

if __name__ == "__main__":
    unittest.main()
